/opt/skynet/skynet $(pwd)/config
