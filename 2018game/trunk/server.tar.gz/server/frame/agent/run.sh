#! /bin/bash
/opt/skynet/skynet $(pwd)/config
