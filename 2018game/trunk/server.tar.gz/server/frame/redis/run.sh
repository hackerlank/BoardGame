redis-server $(pwd)/redis.conf
