sh stop_all.sh

echo start all
./start_frame.sh
./start_game.sh zhaduizi
./start_game.sh mj_cdxz
