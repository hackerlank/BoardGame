echo stop all
./stop_game.sh zhaduizi
./stop_game.sh mj_cdxz
./stop_frame.sh
