print("cc db server start")

local skynet = require "skynet"

skynet.start(function()
    skynet.uniqueservice("clusternode")

    skynet.uniqueservice("room")

    skynet.uniqueservice("console")
end)
