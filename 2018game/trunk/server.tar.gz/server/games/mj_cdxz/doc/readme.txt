游戏名称：成都麻将
游戏文档：游戏规则：血战到底 - 成都.pdf
目录结构：
    doc     文档目录
    hall    大厅
    room    房间
    sproto  协议
    client  测试客户端
    common  公共类库目录
大厅类型 hall_type cdmj
