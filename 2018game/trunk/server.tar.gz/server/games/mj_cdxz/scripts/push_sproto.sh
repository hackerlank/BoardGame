dst=$1/麻将-成都血战
echo copy zhaduizi sproto to $dst

cd `dirname $(pwd)/$0`

cp ../doc/游戏流程.txt $dst

cp ../../common/mjlib/mj_color.lua $dst

cp ../hall/game_rule.lua $dst

# cp ../common/*.lua $dst

cp ../sproto/game.msgid.lua $dst/game_msgid.lua
cp ../sproto/game.sproto $dst
