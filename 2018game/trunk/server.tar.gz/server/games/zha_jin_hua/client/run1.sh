lua client.lua user1
