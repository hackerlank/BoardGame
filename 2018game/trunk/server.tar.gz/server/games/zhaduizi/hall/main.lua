local log = require "cc_log"

log.info("zhaduizi hall server start")

local skynet = require "skynet"

skynet.start(function()
    skynet.uniqueservice("clusternode")

    skynet.uniqueservice("hall")

    skynet.uniqueservice("console")
end)
