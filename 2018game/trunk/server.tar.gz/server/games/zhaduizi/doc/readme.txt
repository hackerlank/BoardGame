游戏名称：炸对子
游戏文档：http://www.runger.net/demo/w8yx_ZDZ/#g=1&p=____w8yx_com
目录结构：
    doc     文档目录
    hall    大厅
    room    房间
    sproto  协议
    client  测试客户端
    common  公共类库目录
大厅类型 hall_type zhaduizi
