dst=$1/炸对子
echo copy zhaduizi sproto to $dst

cd `dirname $(pwd)/$0`

cp ../../common/mjlib/mj_color.lua $dst

cp ../doc/游戏流程.txt $dst

cp ../hall/game_rule.lua $dst

cp ../common/*.lua $dst

cp ../sproto/game.msgid.lua $dst/game_msgid.lua
cp ../sproto/game.sproto $dst
