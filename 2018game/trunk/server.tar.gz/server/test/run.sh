/opt/skynet/skynet ./config
